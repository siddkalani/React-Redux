const Header = () => {
  return <h1 className="display-5 fw-bold text-body-emphasis">Counter</h1>;
};

export default Header;
